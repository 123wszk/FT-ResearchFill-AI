---
name: phytium-techpm-project-apply
description: 在飞腾「科技项目管理系统」（techpm.phytium.com.cn，普元 Primeton coframe/EOS 框架）中完成项目申报登记。当用户提到「科管系统」「科技项目管理系统」「techpm」「飞腾 项目申报/申报登记/申报管理」，或要求把一份项目申报材料（外部项目/自研项目/奖补项目）登记/录入/填写进该系统时使用。会先后登录、导航到「申报管理—项目申报—申报登记—增加」、按材料类型（外部/自研/奖补）判断并填表、保存。
agent_created: true
---

# 飞腾科技项目管理系统 · 项目申报登记

目标系统：`https://techpm.phytium.com.cn`，基于**普元 Primeton coframe / EOS**（接口都是 `com.hkrsoft.*` / `*.biz.ext`）。
本技能与 `phytium-techpm-export`（只读抓取导出）**共用同一套登录/会话/菜单树/字典机制**；区别在**本技能做的是写入操作（申报登记）**。

> ⚠️ **已实测打通 + 2026-10-16 二次只读复核**：登录、菜单树、增加按钮分流、三个新增表单（外部/自研/奖补）的
> 全部真实字段名与标签、「保存」接口 `addProject.biz.ext` 及保存后按类型跳转的编辑页，均以**在线抓取的真实 HTML**验证。
> 下文字段名均为**页面 HTML 实例**，可直接用于构造 POST。

**写入安全红线**：本技能每一步保存/提交都是**真实写库**。任何「保存 / 提交」动作写出前，**必须先把待填字段键值完整列给用户复核**，得到确认后才执行。宁可不做，不可写错。

## 0. 前置

向用户**索要账号密码**（**不要写入任何文件或长期记忆**，会话结束即忘）。用工作区的临时目录存放 cookie 和中间数据，任务结束后清理。

```bash
WORK=<工作区>/tmp_phytium && mkdir -p "$WORK" && cd "$WORK"
UA="https://techpm.phytium.com.cn"
```

## 1. 登录

```bash
curl -sS -k -m 30 -c cj.txt "$UA/default/skins/default/index.jsp" -o /dev/null
curl -sS -k -m 30 -c cj.txt -b cj.txt -L \
  -X POST "$UA/default/coframe/auth/login/org.gocom.components.coframe.auth.login.login.flow" \
  --data-urlencode "original_url=/coframe/auth/login/login.jsp" \
  --data-urlencode "userId=<账号>" --data-urlencode "password=<密码>" \
  -o resp.html -w "HTTP:%{http_code}\n"
```

- 密码**明文提交**，前端 `login()` 只做非空校验，无加密、无验证码。
- 成功标志：302 → `/default/coframe/auth/index.jsp`；最终 `resp.html` 约 38KB（登录页仅 5KB）。
- 注意 **http→https 301**，必须带 `-L`。
- 后续所有请求都带 `-b cj.txt -c cj.txt` 复用 `JSESSIONID`。

## 2. 导航到申报登记列表页 + 「增加」分流

拿菜单树，定位「申报管理 → 项目申报 → 申报登记」页面的 URL：

```bash
curl -sS -k -m 30 -b cj.txt -c cj.txt -X POST \
  "$UA/default/coframe/auth/org.gocom.components.coframe.auth.LoginManager.getMenuData.biz.ext" \
  -H "Content-Type: application/json" -d '{}' -o menu.json
```

返回 `treeNodes` 嵌套树，字段：`menuName` / `linkAction` / `childrenMenuTreeNodeList` / `level` / `menuSeq`。递归展开沿「申报管理→项目申报→申报登记」取 `linkAction` → **`/srms/project/project_manager.jsp`**。抓取列表页：

```bash
curl -sS -k -m 30 -L -b cj.txt -c cj.txt "$UA/default/srms/project/project_manager.jsp" -o page.html
```

**列表页关键结构**：
- 列表接口（`nui-datagrid` 的 `url`）：`com.hkrsoft.srms.projectManager.querySrmsPjProjects.biz.ext`（相对 `/default/srms/project/`）。
- 「增加」是一个 **menubutton**，菜单弹出三个选项，`onclick="addProject(pjClass)"`：

| 菜单项 | pjClass | 新增表单 JSP |
|---|---|---|
| 外部项目 | 1 | `/srms/project/project_wb_add.jsp` |
| 自研项目 | 2 | `/srms/project/project_zy_add.jsp` |
| 奖补项目 | 3 | `/srms/project/project_jb_add.jsp` |

`addProject(pjClass)` 用 `nui.open` 弹窗加载 `/default + url + "?pjClass="+pjClass+"&pjYear="+pjYear`（**实际 URL 前缀 `/default`，并带 `pjClass` / `pjYear` 两个 query 参数**，见 §4 开头——这是隐藏字段 `pjClass` 的取值来源，务必带参请求）。

## 3. 判断项目类型

请用户给出申报登记材料（通常是 docx），或用 python-docx 解析后**让用户确认**类型。对应隐藏字段 `srmsPjProject.pjClass`（即字典 `FT_SBGL_XMGS`）：

| pjClass / dictID | 类型 | 表单 | 复杂度 |
|---|---|---|---|
| 1 | 外部项目 | `project_wb_add.jsp` | **复杂**：基本资料 + 保存后跳 `project_wb_edit.jsp` 补「一~五」五部分 |
| 2 | 自研项目 | `project_zy_add.jsp` | 简单：仅「项目基本资料」 |
| 3 | 奖补项目 | `project_jb_add.jsp` | 简单：仅「项目基本资料」 |

> 判断依据也可从材料结构反推：材料含「一、项目内容」到「五、预算管理」→ 外部项目；只有单张信息表的 → 自研/奖补。
> 填充材料通常是三份固定模板之一：外部材料 `table0(16x4)` 基本信息 + 22 个内容块 + 参与人员/考核/里程碑/预算 5 部分；
> 自研材料 `table0(7x4)` 单表；奖补材料 `table0(6x4)` 单表。解析 docx 后用结构自动反推类型最稳。

## 4. 进「增加」表单，填「项目基本资料」

**⚠️ 关键（实测确认）：新增表单必须以带参 URL 请求**，隐藏字段 `pjClass` 的值由 JSP 服务端从 query 注入：

```bash
# 例（外部 / 自研 / 奖补）
curl -sS -k -m 30 -L -b cj.txt -c cj.txt \
  "$UA/default/srms/project/project_wb_add.jsp?pjClass=1&pjYear=2026" -o add_wb.html
```

若不带参数直接 GET，**三个表单的隐藏 `pjClass` 都会是默认 `1`**（奖补会被存成「外部」！）。
打开对应 `project_XX_add.jsp` 拿到表单 HTML 后，**字段名一律以页面 `name=` 为准**（本文给出的是实测清单）。
三种类型字段**结构不同**，务必按类型对齐。表单 id 均为 `srmsPjProjectform`。

通用要点：
- 隐藏字段（表单顶部 `nui-hidden`）**必须原样带上**，多为伴生的 `xxxId`、主键或配套文本。实测三个表单顶部隐藏字段：
  - 均有：`srmsPjProject.pjClass`（URL 注入的类型值）、**`srmsPjProject.pjPunit`**（=「项目所属单位」文本 orgname，与 `pjApplyOrgId` 配套，前端选树自动回填）、`pjAuthorId`、`pjEmanagerId`、`capRole.tenantId`。
  - 外部另有：`pjImanagerId`、`pjCunit`（主管部门 id）、`pjSource`（专项 id，均成对出现）。
  - 奖补另有：`pjImanagerId`、`pjAunit`、`pjBunit`（**隐藏、无可见控件，POST 传空串即可**，别漏）。
  - 人员选择器是「文本框(name) + 隐藏 id 字段」成对：`pjAuthor`(姓名)+`pjAuthorId`(empid)；`pjEmanager`+`pjEmanagerId`；`pjImanager`(内部管理人)+`pjImanagerId`。
  - 需要 id 的字段（人员/单位/部门/专项），**光填文本 name 不够，id 字段必须一并给对**，否则会因外键校验失败。
- `pjNumber`(项目编号) 是禁用框（`enabled="false"`，emptyText「系统自动生成」），**不填**。
- 日期字段格式 **`yyyy-MM-dd`**（前端保存时也会 `mini.formatDate(dd,"yyyy-MM-dd")` 格式化）；金额是 `nui-spinner`，数值。
  - 材料 docx 里的日期常是中文形态如「2026年-10月-10日」/「2026-09」，**必须先规整成 `yyyy-MM-dd`**（年缺失补 01，日缺失补 01）再填。
- `capRole.tenantId` = `default`（隐藏，原样带）。
- 请求体结构：`{"srmsPjProject":{...所有 srmsPjProject.* 字段(不带前缀)},"capRole":{"tenantId":"default"}}`（`form1.getData()` 的 JSON 形状）。

### 4.1 外部项目 `project_wb_add.jsp`（pjClass=1）

| 标签 | name | 控件/说明 |
|---|---|---|
| 中标年度 | `pjYear` | combobox，默认 2026 |
| 主管部门 | `pjCunitName`（文本）+ `pjCunit`(dictid) | buttonedit 选字典 `FT_SBGL_ZGBM`，**两级联动**：先选主管部门才能选专项 |
| 专项名称 | `pjSourceName`（文本）+ `pjSource`(dictid) | buttonedit 选字典 `FT_SBGL_ZXMC`，依赖已选主管部门 |
| 依托芯片 | `pjSpecial` | 文本，maxLength 100 |
| 指南内容 | `pjGuide` | textarea（可空） |
| 编号 | `pjEnumber` | 文本，**必填**（指南编号） |
| 公开否 | `pjPublic` | 字典 `FT_SBGL_GKF`（G/N/M） |
| 项目编号 | `pjNumber` | 禁用，不填 |
| 项目名称 | `pjName` | 文本，必填 |
| 项目负责人 | `pjAuthor` + `pjAuthorId` | buttonedit 选人员 |
| 外部管理人 | `pjEmanager` + `pjEmanagerId` | buttonedit 选人员 |
| 内部管理人 | `pjImanager` + `pjImanagerId` | buttonedit 选人员 |
| 项目所属单位 | `pjApplyOrgId`（orgid）+ **`pjPunit`(orgname，隐藏)** | treeselect（`querySecondOrg.biz.ext`，选叶子 orgid 后自动回填 pjPunit） |
| 承担类别 | `pjLeader` | 字典 `FT_SBGL_CDLB`，**值决定下两项及「项目预算」区块显隐**（见 §4.4） |
| 牵头单位 | `pjAunit` + `pjAunitId` | buttonedit 选单位 `FT_SBGL_DWMC`；独立/联合牵头时自动=飞腾(1) |
| 参与单位 | `pjBunit`(逗号拼名) + `pjBunitId`(逗号拼 id) | 多选单位 |
| 项目开始/结束时间 | `pjPstime` / `pjPetime` | 日期；结束须 > 开始 |
| 项目状态 | `pjStatus` | 字典 `FT_SBGL_XMZT`，**平台默认 value=1 计划申报** |
| 项目类型 | `pjLevel` | 字典 `FT_SBGL_XMJB`：1地方/2部委/3J口/4横向/5集团及其他 |
| 合同签订时间 | `pjQddate` | 日期（可空；材料常为空，POST 空串） |
| 研发活动类型 | `pjRdtype` | 字典 `FT_SBGL_YFHDLX` |
| 基础研究占比(%) | `pjRatio` | spinner 0–100 |
| **公司预算** 公司总投资(元) | `pjRmoney` | **禁用，自动 = 国拨+自筹+其他**，POST 可给三者之和或由后端算 |
| 国拨经费 | `pjImburse` | spinner，必填 |
| 自筹经费 | `pjSelffunds` | spinner，必填 |
| 其他经费 | `pjOther` | spinner，必填 |
| **项目预算(hideFieldset)** 项目总投资 | `pjRmoney1` | 禁用，自动 = 前三项1 之和 |
| 国拨/自筹/其他 | `pjImburse1` / `pjSelffunds1` / `pjOther1` | 仅当 `pjLeader≠1`(非独立) 时必填/显示 |

### 4.2 自研项目 `project_zy_add.jsp`（pjClass=2）

| 标签 | name | 控件/说明 |
|---|---|---|
| 项目编号 | `pjNumber` | 禁用，不填 |
| 项目名称 | `pjName` | 文本，必填 |
| 项目年度 | `pjYear` | combobox，默认 2026 |
| 项目负责人 | `pjAuthor` + `pjAuthorId` | 选人员 |
| 项目开始/结束时间 | `pjPstime` / `pjPetime` | 日期；结束须 > 开始 |
| 项目所属单位 | `pjApplyOrgId` + **`pjPunit`(orgname，隐藏)** | treeselect |
| 项目总投资(元) | `pjRmoney` | spinner，**HTML 里 enabled=false**——提交前需先启用（`removeAttribute`），否则传默认 0 |
| 项目管理人 | `pjEmanager` + `pjEmanagerId` | **标签叫「项目管理人」**，选人员 |
| 项目状态 | `pjStatus` | 字典 `FT_SBGL_XMZT`，**平台默认 value=2 建设之中**（注意≠外部） |
| 项目类型 | `pjLevel` | 字典 `FT_SBGL_ZYXMLX`：1纯自研 / 2合同项目 |
| 依托芯片 | `pjSpecial` | 文本 |
| 研发活动类型 | `pjRdtype` | 字典 `FT_SBGL_YFHDLX` |
| 基础研究占比(%) | `pjRatio` | spinner |

### 4.3 奖补项目 `project_jb_add.jsp`（pjClass=3）

| 标签 | name | 控件/说明 |
|---|---|---|
| 中标年度 | `pjYear` | combobox |
| 主管部门 | `pjCunit` | **纯文本**（非 buttonedit） |
| 专项名称 | `pjSpecial` | **纯文本**（注意：奖补里"专项名称"占用 `pjSpecial`，语义≠外部） |
| 项目编号 | `pjNumber` | 禁用，不填 |
| 项目名称 | `pjName` | 文本，必填 |
| 项目负责人 | `pjAuthor` + `pjAuthorId` | 选人员 |
| 外部管理人 | `pjEmanager` + `pjEmanagerId` | 选人员 |
| 项目开始/结束时间 | `pjPstime` / `pjPetime` | 日期 |
| 项目所属单位 | `pjApplyOrgId` + **`pjPunit`(orgname，隐藏)** | treeselect |
| 奖补金额(元) | `pjRmoney` | spinner，**可填（非禁用）**，必填 |
| — | 无 `pjStatus`、无 `pjLevel` | 奖补表单**没有**状态/类型字段，别硬填 |
| — | 隐藏 `pjAunit`/`pjBunit`/`pjImanagerId` | **隐藏、无可见控件，POST 空串即可** |

### 4.4 交互联动（构造值时要注意）

- **金额自动求和**：`pjRmoney`(=国拨+自筹+其他) 与 `pjRmoney1`(=imburse1+selffunds1+other1) 由前端 `onPjAmountChange` / `onPjAmount1Change` 自动计算并设为禁用。
  - 外部：给 `pjImburse`/`pjSelffunds`/`pjOther` 即可，`pjRmoney` 会按三者之和回填。
  - **自研**：无三经费拆解、`pjRmoney` 又禁用 → 提交前先 enable 才能写入总投资。
- **承担类别联动**（外部 `pjLeader`，`onvaluechanged="onPjLeaderChange"`）：
  - `1` 独立承担 → 隐藏「项目预算」，牵头单位=飞腾(1)，参与单位/项目预算不要求。
  - `2` 联合承担牵头 → 显示「项目预算」，牵头单位=飞腾(1)，`pjImburse1/…1` 必填。
  - `3` 联合承担参与 → 显示「项目预算」，牵头单位可空、`…1` 可不填。
- **主管部门↔专项两级联动**：前端 `onZgbmChanged(value)` 会按已选主管部门拉专项：
  `com.fcb.erp.tools.dict.queryDict.queryDictInfoByParentDictId.biz.ext?dictTypeId=FT_SBGL_ZXMC&id=<主管部门dictID>`。
  拉专项 id 时优先走这个带父级过滤的接口（没有父级兜底则用 §4.5 的 queryDict 全量拉）。

### 4.5 id 解析（只读）—— 材料里的「姓名/单位/专项名」→ 系统 id

前端弹窗选择器（实测路径，均只读）：
- 人员：`/default/tools/select/personnelSingleSelect.jsp` → 查询接口 `com.hkrsoft.srms.commonManager.queryEntityByCriteriaWithPage.biz.ext`，查出 **empid**
- 部门/单位字典（牵头、参与、主管部门、专项）：`/default/tools/select/dictSingleSelect.jsp?dictTypeId=FT_SBGL_DWMC&type=2`（单选）、`dictMultiSelect.jsp`（多选）、`dictSingleSelect.jsp?dictTypeId=FT_SBGL_ZXMC&type=3&parentTypeId=FT_SBGL_ZGBM&parentDictId=<主管id>` → 查询接口 `org.gocom.components.coframe.dict.DictManager.queryDict.biz.ext`，查出 **dictID**

对应 query 接口参数（Criteria 形状与 export 技能一致，`_entity` 必须传）：

```bash
# 人员：按 工号 empcode 或 姓名 empname 模糊查（材料给姓名/工号任选，工号更准）
curl -sS -k -m 30 -b cj.txt -X POST \
  "$UA/default/srms/commonManager/com.hkrsoft.srms.commonManager.queryEntityByCriteriaWithPage.biz.ext" \
  -H "Content-Type: application/json" \
  -d '{"criteria":{"_entity":"com.hkrsoft.srms.common.OrgEmployeeFt",
       "_expr":[{"empcode":"03238","_op":"like"},{"empname":"","_op":"like"}],
       "_or":[]},"pageIndex":0,"pageSize":20}'
# 返回 data[]，取 empid / empcode / empname / compOrgname

# 字典项：按 字典类型 + 名称 模糊查（FT_SBGL_DWMC / ZGBM / ZXMC …）
curl -sS -k -m 30 -b cj.txt -X POST \
  "$UA/default/coframe/dict/org.gocom.components.coframe.dict.DictManager.queryDict.biz.ext" \
  -H "Content-Type: application/json" \
  -d '{"criteria":{"_entity":"org.gocom.components.coframe.dict.dict.EosDictEntry",
       "_expr":[{"eosDictType.dicttypeid":"FT_SBGL_DWMC","_op":"eq"},{"dictname":"飞腾","_op":"like"}]},
       "pageIndex":0,"pageSize":20,"sortField":"dictid","sortOrder":"asc"}'
# 返回 data[]，取 dictID / dictname
```

> 注意 `_expr` 的下标/写法以弹窗页 HTML `name="criteria/_expr[n]/..."` 为准；两种接口的用法可交叉核对
> `phytium-techpm-export` skill（同为只读 query，`pageSize` 可给大值一次取全）。

## 5. 保存

三个表单**统一走同一保存接口**（前端 `formSaving()` → `$.ajax`，纯前端代码已核实）：

```bash
curl -sS -k -m 30 -b cj.txt -X POST \
  "$UA/default/srms/project/com.hkrsoft.srms.projectManager.addProject.biz.ext" \
  -H "Content-Type: text/json" \
  --data-raw '{"srmsPjProject":{<上面各 name 去掉前缀后组成的字段对象>},"capRole":{"tenantId":"default"}}' \
  -o save_resp.json -w "HTTP:%{http_code}\n"
```

- **Content-Type 必须 `text/json`**（不是 application/json）。
- body 里的 `srmsPjProject.pjClass` 取**带参请求注入后的隐藏值**（外部=1 / 自研=2 / 奖补=3）。
- 日期字段直接给 `yyyy-MM-dd` 字符串；可空日期（如合同签订时间）给空串 `""`。
- 成功响应：**`returnJson.exception == null`** 即成功，取 `returnJson.pid`；失败响应带 `exception` 字段。
- 保存成功前端将跳转（`bootPath + "/srms/project/project_XX_edit.jsp?id=" + returnJson.pid`）：
  - 外部 → `/default/srms/project/project_wb_edit.jsp?id=<pid>`（**含随后五部分补充**）
  - 自研 → `/default/srms/project/project_zy_edit.jsp?id=<pid>`
  - 奖补 → `/default/srms/project/project_jb_edit.jsp?id=<pid>`

## 6. 外部项目补充部分（其余类型直接到 §7）

保存基本资料后进 `project_wb_edit.jsp?id=<pid>`（编辑页 URL 为 `?id=<pid>&isapproval=<行内值>`，从列表行取），**逐个分区进入填写、逐个保存**（别一次写多个分区）。每个分区同样先解析其表单字段名与各自的保存接口。常用补充部分与材料结构对应：

### 一、项目内容
约 22 个内容块（材料里多为「待定」占位，块名常是带斜杠别名的合并长名，取【】括号首名对应）：项目概况、任务定位/目标、产业现状、需求分析、研究背景、企业基本情况、产品市场需求、总体架构、任务方案、建设进度、招标方案、基础条件、配套政策、风险分析、预期成效、创新性分析、研究内容、经济社会效益、知识产权对策、其他内容、前期手续、其他。

### 二、参与人员信息
表格：工号、姓名（示例：03238 邹康）。逐行录入（行数据从 §4.5 人员接口拿到 empid）。

### 三、成果、考核指标及考核方式
三张表：考核指标（序号/指标类型/指标名称/指标要求/考核方式）、知识产权指标（序号/知识产权类型/个数/要求/考核方式）、交付成果（序号/成果类型/个数/要求/考核方式）——注意后两张带「个数」列。

### 四、里程碑计划
表格：序号、开始/结束日期、研发内容、阶段目标、进度百分比（%）。

### 五、预算管理
表格：科目、国拨、自筹、其他、小计。支出科目（15+ 行，表头含合计行「支出预算合计」，材料即 17 行结构）：设备费（含软件）、测试化验加工费、材料费、燃料动力费、会议费、差旅费、合作与交流费、出版/文献/信息传播/知识产权事务费、劳务费、人员费、专家咨询费、管理费、其他支出（其他投资）、自定义预算、间接费（仅科技口项目）。
**注意**：国拨+自筹+其他各列小计、及各科目行小计要自洽，和基本资料里的经费数对得上（合计行 = 各科目行之和）。

## 7. 提交前复核 + 保存

**（写入红线落脚点）** 把最终要写入的字段键值画成清单发给用户，逐一确认无误后再触发保存。保存成功后回读一次列表页（`querySrmsPjProjects.biz.ext`），确认该条项目已出现且类型/状态正确。

## 8. 收尾

- 清理 `$WORK/tmp_phytium`（含 cookie、中间 json/html）。
- 密码等凭据不留任何文件/记忆。
- 向用户报告：登记了哪个项目（名称、类型、编号【如有】）、填了哪些部分、保存结果。

## 与 phytium-techpm-export 的协作约定

- **共用登录/菜单/字典机制**：登录/菜单/字典接口与 export 技能一致（`login.flow` / `getMenuData.biz.ext` / `getDictData.biz.ext`），细节漂移以 `phytium-techpm-export` 的对应章节为准并回填。
- **职责分工**：导出/台账/统计 → `phytium-techpm-export`；申报登记/填表 → 本技能。两者都不做删除项目等破坏性操作。

## 附录：本报申报涉及字典取值（均已实测）

| dictTypeId | 用途 | 取值 |
|---|---|---|
| `FT_SBGL_XMGS` | 项目归属 `pjClass` | 1外部 2自研 3奖补 |
| `FT_SBGL_XMZT` | 项目状态 `pjStatus` | 1计划申报 2建设之中 3已结待验 4完成验收 5未通过 6指南征集 |
| `FT_SBGL_CDLB` | 承担类别 `pjLeader` | 1独立承担 2联合承担牵头 3联合承担参与 |
| `FT_SBGL_XMJB` | 项目类型 `pjLevel`（外部） | 1地方项目 2部委项目 3J口项目 4横向项目 5集团项目及其他 |
| `FT_SBGL_ZYXMLX` | 项目类型 `pjLevel`（自研） | 1纯自研项目 2合同项目 |
| `FT_SBGL_YFHDLX` | 研发活动类型 `pjRdtype` | 1基础研究 2应用研究 3试验发展 |
| `FT_SBGL_GKF` | 公开否 `pjPublic` | G / N / M |
| `FT_SBGL_ZGBM` | 主管部门 | 动态（§4.5 queryDict 拉取，弹窗 `dictSingleSelect.jsp?dictTypeId=FT_SBGL_ZGBM&type=2`） |
| `FT_SBGL_ZXMC` | 专项名称 | 动态，依赖主管部门（§4.4 `queryDictInfoByParentDictId.biz.ext?dictTypeId=FT_SBGL_ZXMC&id=<主管id>`） |
| `FT_SBGL_DWMC` | 单位（牵头/参与） | 1飞腾 …（动态，§4.5 queryDict 拉取） |

> 说明：`FT_SBGL_GKF` 的取值是 G/N/M（仅字母，未见中文别名，页面即以此回显），若材料「公开否」需映射请与用户核对 G=公开 / N=不公开 的对应关系后再填。
